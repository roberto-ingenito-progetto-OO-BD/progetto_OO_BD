package com.company.Model;

/**
 * Tipo di un impiegato
 */
public enum EmpType {
    junior, middle, senior, manager
}
